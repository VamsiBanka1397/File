package com.example.Facebook.Regsitration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FacebookRegsitrationApplicationTests {

	@Test
	void contextLoads() {
	}

}
