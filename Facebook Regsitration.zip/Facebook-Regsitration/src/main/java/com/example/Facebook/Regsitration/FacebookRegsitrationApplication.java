package com.example.Facebook.Regsitration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FacebookRegsitrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacebookRegsitrationApplication.class, args);
	}

}
